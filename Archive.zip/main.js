function handleNextButtonClick(evt)
{
	evt.stopPropagation();
	var targ = evt.target;
	if(!targ) return;
	if(form.currentStep < form.steps.length)
	{
		form.currentStep++;
		renderFormStep(form.currentStep);
	}
}

function handleStepIconClick(evt)
{
	evt.stopPropagation();
	var targ = evt.target;
	if(!targ) return;
	if(targ.id && targ.id === "stepIcons") return;
	while(targ.className.indexOf('stepIcon') === -1 && targ.parentNode)
		targ = targ.parentNode;
	var selectedStep = parseInt(targ.getAttribute("data-step"), 10);
	renderFormStep(selectedStep);
};

function renderFormStep(stepNumber)
{
	form.currentStep = stepNumber;
	if(form.currentStep === form.steps.length)
		Utils.addClass(get("#nextButton"), "hidden");
	else
		Utils.removeClass(get("#nextButton"), "hidden");
	clearFormFields();
	Utils.addClass(get("#stepIcon" + stepNumber), "active");
	get("#stepNumber").textContent = "Step " + (stepNumber);
	get("#stepTitle").textContent = form.steps[stepNumber - 1].title;
	renderFormFields(form.steps[stepNumber - 1].fields);
}

function clearFormFields()
{
	get("#formBody").innerHTML = "";
}

function renderFormFields(fields)
{
	var i, ii;
	for(i = 0, ii = fields.length; i < ii; i++)
	{
		switch(fields[i].type)
		{
			case "text": renderTextField(fields[i]); break;
			case "date": renderDateField(fields[i]); break;
			case "radio": renderRadioField(fields[i]); break;
			case "checkbox": renderCheckboxField(fields[i]); break;
			case "heading": renderHeading(fields[i]); break;
		}
	}
}

function renderTextField(field)
{
	var id = field.name;
	if(field.heading)
	{
		var heading = Utils.createElement({
			class: "fieldHeading"
		});
		heading.textContent = field.heading;
	}
	var fieldWrapper = Utils.createElement({
		class: "fieldWrapper"
	});
	var fieldElement = Utils.createElement({
		strTagName: "input",
		id: id,
		class: "fieldText",
		strName: id
	});
	fieldElement.setAttribute("placeholder", field.label || "");
	if(heading)
		fieldWrapper.appendChild(heading);
	fieldWrapper.appendChild(fieldElement);
	get("#formBody").appendChild(fieldWrapper);
}

function renderHeading(field)
{
	if(field.heading)
	{
		var heading = Utils.createElement({
			class: "fieldHeading"
		});
		heading.textContent = field.heading;
	}
	var fieldWrapper = Utils.createElement({
		class: "fieldWrapper"
	});
	if(heading) fieldWrapper.appendChild(heading);
	get("#formBody").appendChild(fieldWrapper);
}

function renderDateField(field)
{
	var fieldWrapper = Utils.createElement({
		class: "fieldWrapper"
	});
	var fieldElementDay = Utils.createElement({
		strTagName: "input",
		id: field.id + "Day",
		class: "fieldTextInline"
	});
	var fieldElementMonth = Utils.createElement({
		strTagName: "input",
		id: field.id + "Month",
		class: "fieldTextInline"
	});
	var fieldElementYear = Utils.createElement({
		strTagName: "input",
		id: field.id + "Year",
		class: "fieldTextInline"
	});
	fieldElementDay.setAttribute("placeholder", field.label);
	fieldWrapper.appendChild(fieldElementDay);
	fieldWrapper.appendChild(fieldElementMonth);
	fieldWrapper.appendChild(fieldElementYear);
	get("#formBody").appendChild(fieldWrapper);
}

function renderRadioField(field)
{
	var fieldWrapper = Utils.createElement({
		class: "fieldWrapper"
	});
	var id = field.name + "_" + field.label;
	var fieldElement = Utils.createElement({
		strTagName: "input",
		id: id,
		class: "fieldRadio"
	});
	var fieldLabelElement = Utils.createElement({
		strTagName: "label",
		id: id + "Label",
		class: "fieldLabel"
	});
	fieldElement.setAttribute("type", "radio");
	fieldElement.setAttribute("name", field.name);
	fieldElement.setAttribute("placeholder", field.label);
	fieldElement.setAttribute("value", field.value);
	fieldLabelElement.setAttribute("for", id);
	fieldLabelElement.textContent = field.label;
	fieldWrapper.appendChild(fieldElement);
	fieldWrapper.appendChild(fieldLabelElement);
	get("#formBody").appendChild(fieldWrapper);
}

function renderCheckboxField(field)
{
	var fieldWrapper = Utils.createElement({
		class: "fieldWrapper"
	});
	var id = field.name + "_" + field.label;
	var fieldElement = Utils.createElement({
		strTagName: "input",
		id: id,
		class: "fieldCheckbox"
	});
	var fieldLabelElement = Utils.createElement({
		strTagName: "label",
		id: id + "Label",
		class: "fieldLabel"
	});
	fieldElement.setAttribute("type", "checkbox");
	fieldElement.setAttribute("name", field.name);
	fieldElement.setAttribute("placeholder", field.label);
	fieldElement.setAttribute("value", field.value);
	fieldLabelElement.setAttribute("for", id);
	fieldLabelElement.textContent = field.label;
	fieldWrapper.appendChild(fieldElement);
	fieldWrapper.appendChild(fieldLabelElement);
	get("#formBody").appendChild(fieldWrapper);
}

function renderSubmitButton()
{
	var b = document.createElement("button");
	b.textContent = "Submit";
	b.addEventListener("click", handleSubmit);
	get("#formBody").appendChild(b);
}

function addValidationRules()
{
	var v_firstName = new LiveValidation('firstName', { validMessage: 'OK', wait: 10001 });
	v_firstName.add( Validate.Presence, { failureMessage: "You must enter a name" } );
	v_firstName.add( Validate.Format, { pattern: /[^a-z'\- ]+/i, negate: true, failureMessage: "Letters, apostrophes and hyphens only" } );

	var v_lastName = new LiveValidation('lastName', { validMessage: 'OK', wait: 10001 });
	v_lastName.add( Validate.Presence, { failureMessage: "You must enter a name" } );
	v_lastName.add( Validate.Format, { pattern: /[^a-z'\- ]+/i, negate: true, failureMessage: "Letters, apostrophes and hyphens only" } );

	var v_email = new LiveValidation('email', { validMessage: 'OK', wait: 10001 });
	v_email.add( Validate.Presence, { failureMessage: "You must enter an e-mail address" } );
	v_email.add( Validate.Email );
}

function handleSubmit(evt)
{
	if(evt) evt.preventDefault();
	var form = get("#formBody");
	var inputs = form.getElementsByTagName("input");
	fillForm(inputs);
	var data = formToJSON(inputs);
	console.log(data);
}

function isCheckbox(element)
{
	return (element.type === 'checkbox');
}

function isValidElement(element)
{
	return element.name && element.value;
}

function isValidValue(element)
{
	return (!['checkbox', 'radio'].includes(element.type) || element.checked);
}

function formToJSON(elements)
{
	var formData = {};
	var i, ii;
	for(i = 0, ii = elements.length; i < ii; i++)
	{
		var element = elements[i];
		if(isValidElement(element) && isValidValue(element))
		{
			if (isCheckbox(element) && element.checked === true)
			{
				formData[element.name] = (formData[element.name] || []).concat(element.value);
			}
			else
			{
				if(element.type === "radio")
				{
					if(element.value === "yes") formData[element.name] = true;
					else if(element.value === "no") formData[element.name] = false;
				}
				else
					formData[element.name] = element.value;
			}
		}
	}
	return formData;
}

function fillForm(elements)
{
	var formData = {};
	var i, ii;
	for(i = 0, ii = elements.length; i < ii; i++)
	{
		var element = elements[i];
		if(element.type === "checkbox")
			element.checked = "checked";
		else if(element.type === "radio")
			element.checked = "checked";
		else if(element.type === "text")
			element.value = element.name;
	}
	return formData;
}

function main()
{
	get("#stepIcons").addEventListener("click", handleStepIconClick);
	get("#nextButton").addEventListener("click", handleNextButtonClick);
	renderFormStep(1);
	addValidationRules();
	renderSubmitButton();
	// get("#formBody").addEventListener("submit", handleSubmit);
}

main();

var form = {
	steps: [],
	currentStep: 1
};

form.steps.push({
	title: "Needs analysis",
	fields: [
		{ type: "text", name: "firstName", label: "First Name" },
		{ type: "text", name: "lastName", label: "Last Name" },
		{ type: "text", name: "gender", label: "Gender" },
		{ type: "date", name: "birthDate", label: "Date of birth" },
		{ type: "text", name: "phoneMobile", label: "Mobile" },
		{ type: "text", name: "email", label: "Email" },
		{ type: "text", name: "address", label: "Address" },
		{ type: "text", name: "howDidYouHearAboutPARC", label: "", heading: "How did you hear about PARC?" },

		{ type: "heading", heading: "Are you currently Exercising?", },
		{ type: "radio", name: "currentlyExercising", label: "Yes", value: "yes" },
		{ type: "radio", name: "currentlyExercising", label: "No", value: "no" },
		{ type: "text", name: "whatSortOfExercise", label: "Type here", heading: "What sort of exercise?" },

		{ type: "heading", heading: "What results would you like to achieve?", },
		{ type: "checkbox", name: "whatResults", label: "Weight Loss", value: "weight-loss" },
		{ type: "checkbox", name: "whatResults", label: "Reduce stress/anxiety", value: "reduce-stress-anxiety" },
		{ type: "checkbox", name: "whatResults", label: "Social interaction", value: "social-interaction" },
		{ type: "checkbox", name: "whatResults", label: "Maintenance", value: "maintenance" },
		{ type: "checkbox", name: "whatResults", label: "Improve sleep", value: "improve-sleep" },
		{ type: "checkbox", name: "whatResults", label: "Tone and shape", value: "tone-and-shape" },
		{ type: "checkbox", name: "whatResults", label: "Increase fitness/flexibility", value: "increase-fitness-flexibility" },
		{ type: "checkbox", name: "whatResults", label: "Build muscle", value: "build-muscle" },
		{ type: "checkbox", name: "whatResults", label: "Feel better", value: "feel-better" },
		{ type: "checkbox", name: "whatResults", label: "Rehabilitation", value: "rehabilitation" },
		{ type: "checkbox", name: "whatResults", label: "If other, please specify below", value: "other" },
		{ type: "text", name: "whatResultsOtherDetail", label: "Type here" },

		{ type: "text", name: "howManyExerciseDaysAWeek", label: "How many days a week would you like to exercise?" },

		{ type: "heading", heading: "Which facilities or services at PARC interest you most?", },
		{ type: "checkbox", name: "whichFacilities", label: "Gym", value: "Gym" },
		{ type: "checkbox", name: "whichFacilities", label: "Spa/sauna/steam room", value: "SpaSaunaSteamRoom" },
		{ type: "checkbox", name: "whichFacilities", label: "Nutrition", value: "Nutrition" },
		{ type: "checkbox", name: "whichFacilities", label: "50m pool", value: "50mPool" },
		{ type: "checkbox", name: "whichFacilities", label: "Small group training", value: "SmallGroupTraining" },
		{ type: "checkbox", name: "whichFacilities", label: "Warm water pool", value: "WarmWaterPool" },
		{ type: "checkbox", name: "whichFacilities", label: "Wellness centre/day spa", value: "WellnessCentreDaySpa" },
		{ type: "checkbox", name: "whichFacilities", label: "Group exercise", value: "GroupExercise" },
		{ type: "checkbox", name: "whichFacilities", label: "Creche", value: "Creche" },
		{ type: "checkbox", name: "whichFacilities", label: "Physiotherapy", value: "Physiotherapy" },
		{ type: "checkbox", name: "whichFacilities", label: "Cafe", value: "Cafe" },
		{ type: "checkbox", name: "whichFacilities", label: "PARC Fit", value: "ParcFit" },
		{ type: "checkbox", name: "whichFacilities", label: "Personal training", value: "PersonalTraining" },
		{ type: "checkbox", name: "whichFacilities", label: "Swimming lessons", value: "SwimmingLessons" },

		{ type: "text", name: "howMotivated", heading: "How motivated are you to get started?" },

		{ type: "text", name: "whatStoppedYouFromStartingSooner", label: "Type here", heading: "What has stopped you from starting sooner?" },

		{ type: "heading", heading: "Is this still a barrier for you?", },
		{ type: "radio", name: "stillABarrier", label: "Yes", value: "yes"},
		{ type: "radio", name: "stillABarrier", label: "No", value: "no"},

		{ type: "text", name: "whatIsYourAge", heading: "What is your age?" },

		{ type: "heading", heading: "How long have you been thinking about joining PARC?", },
		{ type: "radio", name: "howLongHaveYouBeenThinkingAboutJoining", label: "Less than 1 month", value: "lessThanOneMonth" },
		{ type: "radio", name: "howLongHaveYouBeenThinkingAboutJoining", label: "1-3 months", value: "oneToThreeMonths"},
		{ type: "radio", name: "howLongHaveYouBeenThinkingAboutJoining", label: "3-6 months", value: "threeToSixMonths"},
		{ type: "radio", name: "howLongHaveYouBeenThinkingAboutJoining", label: "6+ months", value: "overSixMonths"},

		{ type: "heading", heading: "Please tick here if you would like to receive updates, special deals or promotional offers from PARC.", },
		{ type: "checkbox", name: "wouldLikeToReceiveUpdates", label: "Yes"},

		{ type: "heading", heading: "Do you have an concession?" },
		{ type: "radio", name: "hasConcession", label: "Yes", value: "yes" },
		{ type: "radio", name: "hasConcession", label: "No", value: "no" },

		{ type: "heading", heading: "Is this a flyers membership?", },
		{ type: "radio", name: "isFlyersMembership", label: "Yes", value: "yes" },
		{ type: "radio", name: "isFlyersMembership", label: "No", value: "no" },

		{ type: "heading", heading: "What term would you like for your membership?", },
		{ type: "radio", name: "membershipTermLength", label: "3 months", value: "3months" },
		{ type: "radio", name: "membershipTermLength", label: "6 months", value: "6months" },
		{ type: "radio", name: "membershipTermLength", label: "12 months", value: "12months" },

		{ type: "heading", heading: "What type of membership would you like?", },
		{ type: "radio", name: "membershipType", label: "Complete", value: "complete" },
		{ type: "radio", name: "membershipType", label: "Aquatic", value: "aquatic" },
		{ type: "radio", name: "membershipType", label: "Active kids (10 - 13 years)", value: "activeKids" },
		{ type: "radio", name: "membershipType", label: "Active Youth (14 - 15 years)", value: "activeYouth" },
		{ type: "radio", name: "membershipType", label: "Active Teen (16 - 17 years)", value: "activeTeen" },
		{ type: "radio", name: "membershipType", label: "Active Life (65+ years)", value: "activeLife" },
		{ type: "radio", name: "membershipType", label: "Corporate", value: "corporate" },
		{ type: "radio", name: "membershipType", label: "Full Throttle - Complete", value: "fullThrottleComplete" },
		{ type: "radio", name: "membershipType", label: "Full Throttle - Aquatic", value: "fullThrottleAquatic" },
	]
});

form.steps.push({
	title: "Who should we call in an emergency?",
	fields: [
		{
			type: "text",
			id: "emergencyContactFirstName",
			label: "First Name"
		},
		{
			type: "text",
			id: "emergencyContactLastName",
			label: "Last Name"
		},
		{
			type: "text",
			id: "emergencyContactRelationship",
			label: "Relationship"
		},
		{
			type: "text",
			id: "emergencyContactPhone",
			label: "Phone"
		}
	]
});

form.steps.push({
	title: "How would you like to pay?",
	fields: [
		{
			type: "text",
			id: "paymentMethod",
			label: "Commbank direct link"
		}
	]
});


form.steps.push({
	title: "What type of membership would you like?",
	fields: [
		{
			type: "radio",
			name: "membershipType",
			id: "membershipType1",
			label: "12 months",
			value: "12_months"
		},
		{
			type: "radio",
			name: "membershipType",
			id: "membershipType2",
			label: "Flexi",
			value: "Flexi"
		}
	]
});


form.steps.push({
	title: "Done!",
	fields: [
		{
			type: "text",
			id: "allDone",
			label: "Not specified"
		}
	]
});



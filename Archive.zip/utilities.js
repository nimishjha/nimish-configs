function get(s)
{
	if(s.indexOf("#") === 0) return document.getElementById(s.substr(1, s.length));
	else if(s.indexOf(".") === 0) return document.getElementsByClassName(s.substr(1, s.length));
	else if(document.getElementsByTagName(s).length) return document.getElementsByTagName(s);
	else return 0;
}

var Utils = {};

Utils.removeWhitespace = function(s)
{
	return s.replace(/\s/g, '');
};

Utils.hasClass = function(ele,cls)
{
	return ele.className.match(new RegExp('(\\s|^)'+cls+'(\\s|$)'));
};

Utils.addClass = function(ele,cls)
{
	if(!Utils.hasClass(ele,cls)) ele.className += " "+cls;
};

Utils.removeClass = function(ele, cls)
{
	if(!ele)
		return;
	var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');
	ele.className = ele.className.replace(reg, ' ');
	if(Utils.removeWhitespace(ele.className) === '') ele.removeAttribute("class");
};

Utils.forEach = function(selector, callback)
{
	var e = get(selector);
	var i = e.length;
	while (i--)
		callback(e[i]);
};

Utils.createElement = function(args)
{
	if(!args)
		return false;

	var elemClass = args.class || undefined;
	var elemId = args.id || undefined;
	var elemInnerHtml = args.strInnerHtml || undefined;
	var elemTagName = args.strTagName || undefined;
	var elemName = args.strName || undefined;
	var elem;

	if(elemTagName)
		elem = document.createElement(elemTagName);
	else
		elem = document.createElement("div");

	if(elem)
	{
		if(elemId)
			elem.id = elemId;
		if(elemClass)
			elem.className = elemClass;
		if(elemInnerHtml && elemInnerHtml.length)
			elem.innerHTML = elemInnerHtml;
		if(elemName)
			elem.name = elemName;
	}

	return elem;
};
